// Import the Invite model from the models directory
const Invite = require('../models/Invite');

// Dummy function to simulate link generation for registration
const generateShareLink = (email) => {
    // Create a registration link with the provided email as a query parameter
    return `http://example.com/register?ref=${encodeURIComponent(email)}`;
};

// Export the registerEmail function to handle incoming email registration requests
exports.registerEmail = async (req, res) => {
    // Destructure the email from the request body
    const { email } = req.body;

    // Validate the email (simple check)
    // Ensure that an email is provided and contains an '@' symbol
    if (!email || !email.includes('@')) {
        // Return a 400 Bad Request response if the email is invalid
        return res.status(400).json({ message: 'Invalid email address.' });
    }

    try {
        // Create a new Invite document using the Invite model
        const newInvite = new Invite({ email });
        // Save the new Invite document to the database
        await newInvite.save();

        // Generate a registration link for the invitee
        const registrationLink = generateShareLink(email);
        // Return a 200 OK response with the registration link
        return res.status(200).json({ registrationLink });
    } catch (error) {
        // Log any errors that occur during the saving process
        console.error('Error saving invite:', error);
        // Return a 500 Internal Server Error response if an error occurs
        return res.status(500).json({ message: 'Server error.' });
    }
};
