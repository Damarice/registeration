// Import the express library to create an Express application
const express = require('express');
// Import the cors library to enable Cross-Origin Resource Sharing
const cors = require('cors');
// Import the body-parser library to parse incoming request bodies
const bodyParser = require('body-parser');
// Import the connectDB function to connect to MongoDB
const connectDB = require('./config/db'); // Ensure this path is correct
// Import the inviteRoutes for handling invite-related requests
const inviteRoutes = require('./routes/inviteRoutes');

// Create a new Express application instance
const app = express();
// Set the port number for the server
const PORT = 5000; // Set your port number here
// Define the MongoDB URI for connecting to the database
const MONGODB_URI = 'mongodb://localhost:27017/inviteDB'; // Set your MongoDB URI here

// Connect to MongoDB using the specified URI
connectDB(MONGODB_URI);

// Use the cors middleware to allow cross-origin requests
app.use(cors());
// Use the bodyParser middleware to parse JSON request bodies
app.use(bodyParser.json());

// Use the invite routes for handling requests to the '/api/invite' endpoint
app.use('/api/invite', inviteRoutes);

// Centralized error handling middleware to catch and respond to errors
app.use((err, req, res, next) => {
    // Log the error stack to the console for debugging
    console.error(err.stack);
    // Return a 500 Internal Server Error response
    res.status(500).json({ message: 'An internal server error occurred.' });
});

// Graceful shutdown on process termination signal (SIGINT)
process.on('SIGINT', () => {
    console.log('Shutting down gracefully...');
    // Exit the process with a success code
    process.exit(0);
});

// Start the server and listen on the specified port
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
