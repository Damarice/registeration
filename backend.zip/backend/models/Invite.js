// Import the mongoose library for MongoDB object modeling
const mongoose = require('mongoose');

// Define the schema for the Invite model
const inviteSchema = new mongoose.Schema({
    email: {
        type: String,           // The type of the email field is String
        required: true,        // The email field is required
        unique: true,          // The email must be unique across all documents
    },
    createdAt: {
        type: Date,            // The type of the createdAt field is Date
        default: Date.now,     // Default value is the current date and time
    },
});

// Create the Invite model using the defined schema
const Invite = mongoose.model('Invite', inviteSchema);

// Export the Invite model so it can be used in other modules
module.exports = Invite;
