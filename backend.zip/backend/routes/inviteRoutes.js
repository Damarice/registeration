// Import the express library to create an Express router
const express = require('express');
// Create a new router instance
const router = express.Router();
// Import the inviteController to handle requests related to invites
const inviteController = require('../controllers/inviteController');

// Define a route to register an email and get the share link
// This route listens for POST requests on the '/register' endpoint
router.post('/register', inviteController.registerEmail);

// Export the router so it can be used in the main application
module.exports = router;
