// Import the mongoose library for MongoDB object modeling
const mongoose = require('mongoose');

// Define an asynchronous function to connect to the MongoDB database
const connectDB = async (uri) => {
    try {
        // Attempt to connect to the MongoDB database using the provided URI
        // The `await` keyword is used to wait for the connection to complete
        await mongoose.connect(uri);
        // Log a success message if the connection is established
        console.log('MongoDB connected successfully!');
    } catch (error) {
        // If an error occurs during the connection, log the error message
        console.error('MongoDB connection error:', error.message);
        // Exit the process with a failure code
        process.exit(1);
    }
};

// Export the connectDB function so it can be used in other modules
module.exports = connectDB;
